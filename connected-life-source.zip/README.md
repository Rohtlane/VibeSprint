# Connected — The Life Game

Educational digital-life simulator for the Telia Challenge. Three playable lifestyles (Campus, Creator, Explorer), personalised names, 6/12/24-month runs, 0–6 random events each month, savings, happiness, contracts, scams, simulated AI advice and classroom hosting.

## Run locally

Use Node.js 24 LTS and npm. No paid AI API or Codex subscription is required to run or edit the app.

```sh
npm run install:ci
npm run dev
```

Open http://localhost:5173. A clean clone automatically uses the portable execution profile. Solo play saves in browser localStorage. Saved games and classroom data are not included in the repository.

## Build and check

```sh
npm run build
node node_modules/typescript/bin/tsc --noEmit
node tests/engine.mjs
node tests/education.mjs
node tests/replayability.mjs
```

The build emits a Cloudflare Worker in dist/server and browser assets in dist/client. This is a server-backed app, so GitHub Pages alone is not a complete deployment target.

## Local classroom database

After a successful build, initialise local D1 using the generated configuration:

```sh
npx wrangler d1 execute DB --local --config dist/server/wrangler.json --file drizzle/0000_handy_thor.sql
```

Run the dev server and then `node tests/classroom.mjs` to exercise the local classroom API. This test creates disposable local rooms. Production database credentials and data are not included.

## Continue with Claude or another editor

Read HANDOFF.md first. Open the whole project folder, install dependencies and run the commands above. No dependency on the original chat is required. GitHub access lets a collaborator work on the source; it does not grant access to the existing private deployed site.

All prices, banking responses and AI messages are fictional examples. No live AI model, payment service, SIM or Telia customer data is connected. The existing site is private; classroom codes alone cannot bypass its access controls.
