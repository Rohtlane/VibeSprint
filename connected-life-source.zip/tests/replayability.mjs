import assert from 'node:assert/strict';
import {fresh,apply,events,queueFor,lifestyles,goalFor,replay} from '../app/engine.ts';
const setup={name:'Jo',lifestyle:'student',device:'repair',plan:'light',net:'shared',months:6,guided:false,seed:42};
function decision(id,value,patch={}){let s=apply(fresh(setup),{type:'advance',queue:[id]});s=apply({...s,...patch},{type:'continue'});return apply(s,{type:'choice',event:id,value});}
assert.equal(decision('roadwork','skip',{activeNet:'wireless'}).delta.cash,0);
assert.equal(decision('ai','verify').aiChecked,true);
assert.equal(decision('ai','trust').aiChecked,false);
assert.equal(decision('ai','trust').delta.cash,0);
assert.match(decision('ai','trust').response,/€255/);
assert.equal(decision('friends','free').friends,1);
assert.equal(goalFor({...setup,months:24}),1200);
assert.equal(goalFor({...setup,lifestyle:undefined,months:24}),300);
const choices={parcel:'check',trial:'skip',renew:'cancel',repair:'wait',gig:'skip',interview:'skip',friends:'free',travel:'stay',move:'stay',data:'wait',sale:'skip',password:'secure',refund:'sell',rain:'book',study:'library',deadline:'campus',buddy:'join',ai:'verify',client:'skip',collab:'go',referral:'yes',roam:'local',roadwork:'skip',reunion:'go'};
let runs=0;
for(const l of lifestyles)for(const months of [6,12,24])for(const seed of [1,27,42,99])for(const device of ['repair','new']){
 let s=fresh({...setup,lifestyle:l.id,months,seed,device});
 while(!s.ended){
  if(s.phase==='ready'||s.phase==='review')s=apply(s,{type:'advance'});
  else if(s.phase==='bill'||s.response)s=apply(s,{type:'continue'});
  else if(s.phase==='event'){const id=s.queue[s.index];s=apply(s,{type:'choice',event:id,value:choices[id]});}
  else if(s.phase==='manage'){s=apply(s,{type:'save',value:Math.min(Math.ceil(goalFor(s.setup)/months),Math.max(0,s.cash))});s=apply(s,{type:'continue'});}
  else throw Error(s.phase);
  assert(s.queue.length<=6);assert(Number.isFinite(s.cash));
 }
 assert.equal(s.month,months);assert(s.savings>=goalFor(s.setup));
 const r=replay(s,s.setup.plan);assert.equal(r.flags.length,0);assert.equal(r.game.cash,s.cash);assert.equal(r.game.wins,s.wins);runs++;
}
for(let seed=0;seed<100;seed++){const s={...fresh({...setup,seed}),month:1};const q=queueFor(s);assert(!q.includes('client'));assert(!q.includes('buddy'));assert(!q.includes('reunion'));assert(q.every(id=>!events.find(e=>e.id===id).lifestyles||events.find(e=>e.id===id).lifestyles.includes('student')));}
console.log(`PASS: ${runs} full lifestyle runs, budget/premium savings viability, 6/12/24 months, causal eligibility, AI source checking, legacy goals, exact replays and no reward for skipping work.`);
