import assert from 'node:assert/strict';
import {fresh,apply,charges,commitments,serviceQuote,normalizeGame,replay} from '../app/engine.ts';
const config={name:'Robin',device:'repair',plan:'flex',net:'shared',months:6,guided:false,seed:42};
function manage(conf=config){return apply(apply(fresh(conf),{type:'advance',queue:[]}),{type:'continue'});}
let s=manage();assert.equal(s.happy,65,'Old phone must not penalise happiness on quiet months');assert.equal(s.setup.name,'Robin');
const q=serviceQuote(s,'plan','promo');assert.equal(q.exit,0);assert.equal(q.nextMonthly,10);s=apply(s,{type:'service',event:'plan',value:'promo'});assert.equal(s.activePlan,'flex');assert.equal(charges(s,2)[0].amount,10);assert.equal(commitments(s).find(x=>x.name.includes('Offer A')).cost,255);assert.throws(()=>apply(s,{type:'service',event:'plan',value:'light'}),/already scheduled/);
s=apply(s,{type:'continue'});s=apply(s,{type:'advance',queue:[]});assert.equal(s.activePlan,'promo');assert.equal(s.planStart,2);assert.equal(charges(s,4)[0].amount,10);assert.equal(charges(s,5)[0].amount,25);assert.equal(serviceQuote(s,'plan','none').exit,245);
let f=manage();f=apply(f,{type:'service',event:'net',value:'none'});f=apply(f,{type:'continue'});f=apply(f,{type:'advance',queue:[]});assert.equal(f.activeNet,'none');assert.equal(charges(f,3)[1].amount,0);assert.equal(replay(f,'flex').flags.length,0);
let b=manage({...config,plan:'promo',net:'fiber'});assert.equal(serviceQuote(b,'net','none').exit,242);assert.equal(serviceQuote(b,'plan','none').exit,245);assert.throws(()=>apply({...b,cash:1},{type:'service',event:'plan',value:'none'}),/Not enough/);assert.throws(()=>apply({...b,blocked:true},{type:'service',event:'net',value:'shared'}),/blocked/);
const old={...s};delete old.activePlan;delete old.activeNet;delete old.pending;assert.equal(normalizeGame(old).activePlan,'flex');assert.deepEqual(normalizeGame(old).pending,[]);
console.log('PASS: names, old-phone fairness, cancellation, switching, effective dates, new promotional clock, exit fees, blocked cards, replay and legacy-save migration.');
