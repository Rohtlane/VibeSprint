import assert from 'node:assert/strict';
const base='http://localhost:5173/api/classroom';
async function post(body,token){const r=await fetch(base,{method:'POST',headers:{'Content-Type':'application/json',...(token?{'x-room-token':token}:{})},body:JSON.stringify(body)});return {status:r.status,data:await r.json()};}
let h=await post({action:'host',months:6});assert.equal(h.status,200,JSON.stringify(h.data));const host=h.data;
let j=await post({action:'join',code:host.code,nickname:'Test Player'});assert.equal(j.status,200);const student=j.data;
let forbidden=await post({action:'status',code:host.code,status:'playing'},student.token);assert.equal(forbidden.status,403);
assert.equal((await post({action:'status',code:host.code,status:'playing'},host.token)).status,200);
assert.equal((await post({action:'progress',code:host.code,month:2,savings:90,happiness:75,finished:false},student.token)).status,200);
const status=await fetch(base+'?code='+host.code,{headers:{'x-room-token':host.token}}).then(r=>r.json());assert.equal(status.players[0].savings,90);assert.equal(status.status,'playing');
const studentStatus=await fetch(base+'?code='+host.code,{headers:{'x-room-token':student.token}}).then(r=>r.json());assert.equal(studentStatus.players,undefined);
assert.equal((await post({action:'status',code:host.code,status:'paused'},host.token)).status,200);
assert.equal((await post({action:'status',code:host.code,status:'closed'},host.token)).status,200);
assert.equal((await post({action:'join',code:host.code,nickname:'Late join'})).status,409);
console.log('PASS: host, join, teacher controls, student authorization, progress sync, private roster, pause, closed room.');
