// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import {integer,sqliteTable,text,index} from 'drizzle-orm/sqlite-core';
export const classrooms=sqliteTable('classrooms',{code:text('code').primaryKey(),hostToken:text('host_token').notNull(),months:integer('months').notNull(),seed:integer('seed').notNull(),status:text('status').notNull()});
export const players=sqliteTable('players',{id:text('id').primaryKey(),room:text('room').notNull().references(()=>classrooms.code),token:text('token').notNull(),nickname:text('nickname').notNull(),month:integer('month').notNull().default(0),savings:integer('savings').notNull().default(0),happiness:integer('happiness').notNull().default(65),finished:integer('finished').notNull().default(0),joinedAt:integer('joined_at').notNull().default(0)},table=>[index('idx_players_room').on(table.room)]);
