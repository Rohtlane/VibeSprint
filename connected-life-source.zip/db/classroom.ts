import {env} from 'cloudflare:workers';
export function classroomDb(){if(!env.DB)throw new Error('Classroom storage is unavailable. Please try again later.');return env.DB;}
