CREATE TABLE `classrooms` (
	`code` text PRIMARY KEY NOT NULL,
	`host_token` text NOT NULL,
	`months` integer NOT NULL,
	`seed` integer NOT NULL,
	`status` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `players` (
	`id` text PRIMARY KEY NOT NULL,
	`room` text NOT NULL,
	`token` text NOT NULL,
	`nickname` text NOT NULL,
	`month` integer DEFAULT 0 NOT NULL,
	`savings` integer DEFAULT 0 NOT NULL,
	`happiness` integer DEFAULT 65 NOT NULL,
	`finished` integer DEFAULT 0 NOT NULL,
	`joined_at` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`room`) REFERENCES `classrooms`(`code`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_players_room` ON `players` (`room`);